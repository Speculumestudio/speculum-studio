# Pasta de Ferramentas e Skills

Aqui moram seus scripts locais em Python, modelos de código, prompts reutilizáveis e automações.
