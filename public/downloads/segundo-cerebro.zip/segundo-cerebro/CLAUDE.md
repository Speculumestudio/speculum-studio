# Segundo Cérebro · Diretrizes Operacionais (Speculum OS)

Este arquivo é a constituição do seu sistema. Toda IA que operar nesta pasta deve ler este arquivo primeiro.

## 1. Diretrizes Inegociáveis
1. Leitura Prévia: Antes de criar qualquer texto ou código, consulte 01-clientes/ para entender o tom de voz e 02-ofertas/ para ver o escopo.
2. Tom Humano e Autêntico: Proibido usar jargões clichês de IA (como 'no mundo acelerado de hoje', 'revolucionário', 'mergulhe'). Nunca use travessões soltos no meio do texto.
3. Segurança: Nunca apague ou altere arquivos importantes sem a confirmação explícita do usuário.
4. Histórico: Toda entrega final deve ser registrada na pasta 04-projetos/.
