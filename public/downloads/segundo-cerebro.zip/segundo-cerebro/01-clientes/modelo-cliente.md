# Ficha de Cliente · Modelo

- Nome do Cliente / Marca: 
- Nicho / Mercado: 
- Tom de Voz: Direto, sóbrio, técnico, elegante
- O que o cliente ODEIA: Textos prolixos, promessas exageradas, clichês de marketing
- Oferta Contratada: 
- Histórico de Entregas: 
