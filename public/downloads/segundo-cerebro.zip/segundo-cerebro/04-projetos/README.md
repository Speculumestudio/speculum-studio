# Pasta de Projetos Ativos

Cada trabalho novo entra aqui como uma pasta ou nota com data.
Exemplo: 2026-11-20_Roteiro_Campanha_Natal/
