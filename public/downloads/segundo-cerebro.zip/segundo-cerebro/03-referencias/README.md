# Banco de Referências Aprovadas

Guarde aqui links, transcrições e exemplos reais de roteiros, carrosséis, vídeos e páginas que representam o padrão de ouro que você deseja que a IA imite.
